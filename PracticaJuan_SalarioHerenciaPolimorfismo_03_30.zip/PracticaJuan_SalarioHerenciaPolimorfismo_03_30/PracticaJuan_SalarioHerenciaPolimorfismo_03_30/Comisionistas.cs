﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PracticaJuan_SalarioHerenciaPolimorfismo_03_30
{
    class Comisionistas : Empleado
    {
        private double ventas; //Ventas realizadas por el empleado
        private double salario; //Salario del empleado

        //Constructor
        public Comisionistas(string documento, string nombre, string apellido, string direccion, double ventas) : base(documento, nombre, apellido, direccion)
        {
            this.ventas = ventas;
        }

        //Calculo del sueldo
        public override string calcularSueldo()
        {
            salario = (ventas * 0.43); //Es salario es un 43% de sus ventas 
            return salario.ToString("N2"); //retornamos el salario
        }

        public override void crearEntrada(string doc, string nom, string ape, string dir, ListView list)
        {
            if (!string.IsNullOrEmpty(doc) && !string.IsNullOrEmpty(nom) && !string.IsNullOrEmpty(ape) && !string.IsNullOrEmpty(dir))
            {
                ListViewItem item = new ListViewItem("Comisionista");
                item.SubItems.Add(doc);
                item.SubItems.Add(ape);
                item.SubItems.Add(nom);
                item.SubItems.Add(dir);
                item.SubItems.Add(this.salario.ToString());
                list.Items.Add(item);
                this.salario = 0;
            }
            else
                throw new Exception("Ingrese todos los campos parce");
        }
    }
}
