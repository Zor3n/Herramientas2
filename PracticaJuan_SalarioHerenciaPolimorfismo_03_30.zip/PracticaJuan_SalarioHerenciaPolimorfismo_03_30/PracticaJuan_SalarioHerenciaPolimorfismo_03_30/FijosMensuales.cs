﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PracticaJuan_SalarioHerenciaPolimorfismo_03_30
{
    class FijosMensuales : Empleado
    {
        private double salario; //Salario del empleado

        //Constructor
        public FijosMensuales(string documento, string nombre, string apellido, string direccion, double salario = 870000) :base(documento,nombre,apellido,direccion)
        {
            this.salario = salario;
        }


        public override string calcularSueldo()
        {
            return salario.ToString("N2");
        }

        public override void crearEntrada(string doc, string nom, string ape, string dir, ListView list)
        {
            if (!string.IsNullOrEmpty(doc) && !string.IsNullOrEmpty(nom) && !string.IsNullOrEmpty(ape) && !string.IsNullOrEmpty(dir))
            {
                ListViewItem item = new ListViewItem("Fijo Mensual");
                item.SubItems.Add(doc);
                item.SubItems.Add(ape);
                item.SubItems.Add(nom);
                item.SubItems.Add(dir);
                item.SubItems.Add(this.salario.ToString());
                list.Items.Add(item);
                this.salario = 0;
            }
            else
                throw new Exception("Ingrese todos los campos parce");
        }
    }
}
