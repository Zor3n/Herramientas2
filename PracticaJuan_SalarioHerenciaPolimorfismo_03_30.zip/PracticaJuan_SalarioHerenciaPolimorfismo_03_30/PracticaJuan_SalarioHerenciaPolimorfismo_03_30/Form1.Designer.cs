﻿namespace PracticaJuan_SalarioHerenciaPolimorfismo_03_30
{
    partial class frmPrincipal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cbEmpleados = new System.Windows.Forms.ComboBox();
            this.gbEmpleado = new System.Windows.Forms.GroupBox();
            this.lblSaldoFijoJefe = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.txtSaldoHora = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.txtHorasTrabajadas = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.btnAgregar = new System.Windows.Forms.Button();
            this.txtVentas = new System.Windows.Forms.TextBox();
            this.lblPorcentaje = new System.Windows.Forms.Label();
            this.lblSalarioComisionista = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.lblSalarioFijo = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.txtDireccion = new System.Windows.Forms.TextBox();
            this.txtApellido = new System.Windows.Forms.TextBox();
            this.txtNombre = new System.Windows.Forms.TextBox();
            this.txtDocumento = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lvDatos = new System.Windows.Forms.ListView();
            this.lblNomina = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.colDoc = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colApe = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colNomb = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colDir = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colSal = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colTipo = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.label2 = new System.Windows.Forms.Label();
            this.lblSaldoHoras = new System.Windows.Forms.Label();
            this.gbComisionista = new System.Windows.Forms.GroupBox();
            this.gbHoras = new System.Windows.Forms.GroupBox();
            this.btnSalir = new System.Windows.Forms.Button();
            this.gbEmpleado.SuspendLayout();
            this.gbComisionista.SuspendLayout();
            this.gbHoras.SuspendLayout();
            this.SuspendLayout();
            // 
            // cbEmpleados
            // 
            this.cbEmpleados.FormattingEnabled = true;
            this.cbEmpleados.Location = new System.Drawing.Point(252, 12);
            this.cbEmpleados.Name = "cbEmpleados";
            this.cbEmpleados.Size = new System.Drawing.Size(204, 27);
            this.cbEmpleados.TabIndex = 0;
            this.cbEmpleados.SelectedIndexChanged += new System.EventHandler(this.cbEmpleados_SelectedIndexChanged);
            // 
            // gbEmpleado
            // 
            this.gbEmpleado.Controls.Add(this.btnSalir);
            this.gbEmpleado.Controls.Add(this.gbComisionista);
            this.gbEmpleado.Controls.Add(this.gbHoras);
            this.gbEmpleado.Controls.Add(this.lblSaldoFijoJefe);
            this.gbEmpleado.Controls.Add(this.label12);
            this.gbEmpleado.Controls.Add(this.btnAgregar);
            this.gbEmpleado.Controls.Add(this.lblSalarioFijo);
            this.gbEmpleado.Controls.Add(this.label7);
            this.gbEmpleado.Controls.Add(this.txtDireccion);
            this.gbEmpleado.Controls.Add(this.txtApellido);
            this.gbEmpleado.Controls.Add(this.txtNombre);
            this.gbEmpleado.Controls.Add(this.txtDocumento);
            this.gbEmpleado.Controls.Add(this.label6);
            this.gbEmpleado.Controls.Add(this.label5);
            this.gbEmpleado.Controls.Add(this.label4);
            this.gbEmpleado.Controls.Add(this.label3);
            this.gbEmpleado.Enabled = false;
            this.gbEmpleado.Location = new System.Drawing.Point(35, 89);
            this.gbEmpleado.Name = "gbEmpleado";
            this.gbEmpleado.Size = new System.Drawing.Size(487, 408);
            this.gbEmpleado.TabIndex = 1;
            this.gbEmpleado.TabStop = false;
            this.gbEmpleado.Text = "Empleado";
            // 
            // lblSaldoFijoJefe
            // 
            this.lblSaldoFijoJefe.AutoSize = true;
            this.lblSaldoFijoJefe.Location = new System.Drawing.Point(377, 57);
            this.lblSaldoFijoJefe.Name = "lblSaldoFijoJefe";
            this.lblSaldoFijoJefe.Size = new System.Drawing.Size(93, 19);
            this.lblSaldoFijoJefe.TabIndex = 6;
            this.lblSaldoFijoJefe.Text = "SaldoFijoJefe";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(353, 38);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(101, 19);
            this.label12.TabIndex = 7;
            this.label12.Text = "Saldo del jefe:";
            // 
            // txtSaldoHora
            // 
            this.txtSaldoHora.Location = new System.Drawing.Point(159, 59);
            this.txtSaldoHora.Name = "txtSaldoHora";
            this.txtSaldoHora.Size = new System.Drawing.Size(112, 27);
            this.txtSaldoHora.TabIndex = 7;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(38, 59);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(115, 19);
            this.label11.TabIndex = 6;
            this.label11.Text = "Salario por hora:";
            // 
            // txtHorasTrabajadas
            // 
            this.txtHorasTrabajadas.Location = new System.Drawing.Point(159, 26);
            this.txtHorasTrabajadas.Name = "txtHorasTrabajadas";
            this.txtHorasTrabajadas.Size = new System.Drawing.Size(57, 27);
            this.txtHorasTrabajadas.TabIndex = 6;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(29, 29);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(124, 19);
            this.label10.TabIndex = 17;
            this.label10.Text = "Horas trabajadas:";
            // 
            // btnAgregar
            // 
            this.btnAgregar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAgregar.Location = new System.Drawing.Point(361, 318);
            this.btnAgregar.Name = "btnAgregar";
            this.btnAgregar.Size = new System.Drawing.Size(93, 37);
            this.btnAgregar.TabIndex = 7;
            this.btnAgregar.Text = "Añadir";
            this.btnAgregar.UseVisualStyleBackColor = true;
            this.btnAgregar.Click += new System.EventHandler(this.btnAgregar_Click);
            // 
            // txtVentas
            // 
            this.txtVentas.Location = new System.Drawing.Point(124, 26);
            this.txtVentas.Name = "txtVentas";
            this.txtVentas.Size = new System.Drawing.Size(159, 27);
            this.txtVentas.TabIndex = 8;
            // 
            // lblPorcentaje
            // 
            this.lblPorcentaje.AutoSize = true;
            this.lblPorcentaje.Location = new System.Drawing.Point(120, 56);
            this.lblPorcentaje.Name = "lblPorcentaje";
            this.lblPorcentaje.Size = new System.Drawing.Size(36, 19);
            this.lblPorcentaje.TabIndex = 16;
            this.lblPorcentaje.Text = "43%";
            // 
            // lblSalarioComisionista
            // 
            this.lblSalarioComisionista.AutoSize = true;
            this.lblSalarioComisionista.Location = new System.Drawing.Point(158, 56);
            this.lblSalarioComisionista.Name = "lblSalarioComisionista";
            this.lblSalarioComisionista.Size = new System.Drawing.Size(93, 19);
            this.lblSalarioComisionista.TabIndex = 14;
            this.lblSalarioComisionista.Text = "Comisionista";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(50, 29);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(57, 19);
            this.label9.TabIndex = 15;
            this.label9.Text = "Ventas:";
            // 
            // lblSalarioFijo
            // 
            this.lblSalarioFijo.AutoSize = true;
            this.lblSalarioFijo.Location = new System.Drawing.Point(394, 121);
            this.lblSalarioFijo.Name = "lblSalarioFijo";
            this.lblSalarioFijo.Size = new System.Drawing.Size(76, 19);
            this.lblSalarioFijo.TabIndex = 8;
            this.lblSalarioFijo.Text = "SalarioFijo";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(326, 102);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(144, 19);
            this.label7.TabIndex = 8;
            this.label7.Text = "Salario Fijo Mensual:";
            // 
            // txtDireccion
            // 
            this.txtDireccion.Location = new System.Drawing.Point(112, 135);
            this.txtDireccion.Name = "txtDireccion";
            this.txtDireccion.Size = new System.Drawing.Size(204, 27);
            this.txtDireccion.TabIndex = 13;
            this.txtDireccion.Text = "FFFFFF";
            // 
            // txtApellido
            // 
            this.txtApellido.Location = new System.Drawing.Point(112, 102);
            this.txtApellido.Name = "txtApellido";
            this.txtApellido.Size = new System.Drawing.Size(204, 27);
            this.txtApellido.TabIndex = 12;
            this.txtApellido.Text = "Johnson";
            // 
            // txtNombre
            // 
            this.txtNombre.Location = new System.Drawing.Point(112, 69);
            this.txtNombre.Name = "txtNombre";
            this.txtNombre.Size = new System.Drawing.Size(204, 27);
            this.txtNombre.TabIndex = 11;
            this.txtNombre.Text = "Carl";
            // 
            // txtDocumento
            // 
            this.txtDocumento.Location = new System.Drawing.Point(112, 35);
            this.txtDocumento.Name = "txtDocumento";
            this.txtDocumento.Size = new System.Drawing.Size(204, 27);
            this.txtDocumento.TabIndex = 7;
            this.txtDocumento.Text = "100001";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(32, 138);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(74, 19);
            this.label6.TabIndex = 10;
            this.label6.Text = "Direccion:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(40, 105);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(66, 19);
            this.label5.TabIndex = 9;
            this.label5.Text = "Apellido:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(42, 72);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(64, 19);
            this.label4.TabIndex = 8;
            this.label4.Text = "Nombre:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(19, 38);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(87, 19);
            this.label3.TabIndex = 7;
            this.label3.Text = "Documento:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(31, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(215, 19);
            this.label1.TabIndex = 2;
            this.label1.Text = "Seleccione el tipo de Empleado:";
            // 
            // lvDatos
            // 
            this.lvDatos.AllowColumnReorder = true;
            this.lvDatos.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.colTipo,
            this.colDoc,
            this.colApe,
            this.colNomb,
            this.colDir,
            this.colSal});
            this.lvDatos.GridLines = true;
            this.lvDatos.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
            this.lvDatos.HideSelection = false;
            this.lvDatos.Location = new System.Drawing.Point(541, 0);
            this.lvDatos.Name = "lvDatos";
            this.lvDatos.Size = new System.Drawing.Size(684, 519);
            this.lvDatos.TabIndex = 3;
            this.lvDatos.UseCompatibleStateImageBehavior = false;
            this.lvDatos.View = System.Windows.Forms.View.Details;
            // 
            // lblNomina
            // 
            this.lblNomina.AutoSize = true;
            this.lblNomina.Location = new System.Drawing.Point(355, 52);
            this.lblNomina.Name = "lblNomina";
            this.lblNomina.Size = new System.Drawing.Size(59, 19);
            this.lblNomina.TabIndex = 18;
            this.lblNomina.Text = "Nomina";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(248, 52);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(99, 19);
            this.label13.TabIndex = 19;
            this.label13.Text = "Nomina Total:";
            // 
            // colDoc
            // 
            this.colDoc.Text = "Documento";
            this.colDoc.Width = 114;
            // 
            // colApe
            // 
            this.colApe.Text = "Apellido";
            this.colApe.Width = 114;
            // 
            // colNomb
            // 
            this.colNomb.Text = "Nombre";
            this.colNomb.Width = 114;
            // 
            // colDir
            // 
            this.colDir.Text = "Direccion";
            this.colDir.Width = 114;
            // 
            // colSal
            // 
            this.colSal.Text = "Salario";
            this.colSal.Width = 114;
            // 
            // colTipo
            // 
            this.colTipo.Text = "Tipo";
            this.colTipo.Width = 114;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(71, 97);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(82, 19);
            this.label2.TabIndex = 18;
            this.label2.Text = "Saldo total:";
            // 
            // lblSaldoHoras
            // 
            this.lblSaldoHoras.AutoSize = true;
            this.lblSaldoHoras.Location = new System.Drawing.Point(159, 97);
            this.lblSaldoHoras.Name = "lblSaldoHoras";
            this.lblSaldoHoras.Size = new System.Drawing.Size(82, 19);
            this.lblSaldoHoras.TabIndex = 19;
            this.lblSaldoHoras.Text = "SaldoHoras";
            // 
            // gbComisionista
            // 
            this.gbComisionista.Controls.Add(this.txtVentas);
            this.gbComisionista.Controls.Add(this.label9);
            this.gbComisionista.Controls.Add(this.lblSalarioComisionista);
            this.gbComisionista.Controls.Add(this.lblPorcentaje);
            this.gbComisionista.Enabled = false;
            this.gbComisionista.Location = new System.Drawing.Point(58, 187);
            this.gbComisionista.Name = "gbComisionista";
            this.gbComisionista.Size = new System.Drawing.Size(289, 84);
            this.gbComisionista.TabIndex = 20;
            this.gbComisionista.TabStop = false;
            this.gbComisionista.Text = "Comisionista";
            // 
            // gbHoras
            // 
            this.gbHoras.Controls.Add(this.lblSaldoHoras);
            this.gbHoras.Controls.Add(this.label10);
            this.gbHoras.Controls.Add(this.label2);
            this.gbHoras.Controls.Add(this.txtHorasTrabajadas);
            this.gbHoras.Controls.Add(this.label11);
            this.gbHoras.Controls.Add(this.txtSaldoHora);
            this.gbHoras.Enabled = false;
            this.gbHoras.Location = new System.Drawing.Point(58, 277);
            this.gbHoras.Name = "gbHoras";
            this.gbHoras.Size = new System.Drawing.Size(289, 131);
            this.gbHoras.TabIndex = 21;
            this.gbHoras.TabStop = false;
            this.gbHoras.Text = "Por Horas";
            // 
            // btnSalir
            // 
            this.btnSalir.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSalir.Location = new System.Drawing.Point(361, 361);
            this.btnSalir.Name = "btnSalir";
            this.btnSalir.Size = new System.Drawing.Size(93, 37);
            this.btnSalir.TabIndex = 22;
            this.btnSalir.Text = "Salir";
            this.btnSalir.UseVisualStyleBackColor = true;
            this.btnSalir.Click += new System.EventHandler(this.btnSalir_Click);
            // 
            // frmPrincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1225, 519);
            this.Controls.Add(this.lblNomina);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.lvDatos);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.gbEmpleado);
            this.Controls.Add(this.cbEmpleados);
            this.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "frmPrincipal";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Salario";
            this.gbEmpleado.ResumeLayout(false);
            this.gbEmpleado.PerformLayout();
            this.gbComisionista.ResumeLayout(false);
            this.gbComisionista.PerformLayout();
            this.gbHoras.ResumeLayout(false);
            this.gbHoras.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cbEmpleados;
        private System.Windows.Forms.GroupBox gbEmpleado;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtDireccion;
        private System.Windows.Forms.TextBox txtApellido;
        private System.Windows.Forms.TextBox txtNombre;
        private System.Windows.Forms.TextBox txtDocumento;
        private System.Windows.Forms.Button btnAgregar;
        private System.Windows.Forms.Label lblSalarioFijo;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtVentas;
        private System.Windows.Forms.Label lblPorcentaje;
        private System.Windows.Forms.Label lblSalarioComisionista;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtSaldoHora;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtHorasTrabajadas;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label lblSaldoFijoJefe;
        private System.Windows.Forms.ListView lvDatos;
        private System.Windows.Forms.Label lblNomina;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.ColumnHeader colDoc;
        private System.Windows.Forms.ColumnHeader colApe;
        private System.Windows.Forms.ColumnHeader colNomb;
        private System.Windows.Forms.ColumnHeader colDir;
        private System.Windows.Forms.ColumnHeader colSal;
        private System.Windows.Forms.ColumnHeader colTipo;
        private System.Windows.Forms.Label lblSaldoHoras;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox gbComisionista;
        private System.Windows.Forms.GroupBox gbHoras;
        private System.Windows.Forms.Button btnSalir;
    }
}

