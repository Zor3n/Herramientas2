﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PracticaJuan_SalarioHerenciaPolimorfismo_03_30
{
    abstract class Empleado
    {
        private string documento;
        private string nombre;
        private string apellido;
        private string direccion;

        public Empleado(string documento, string nombre, string apellido, string direccion)
        {
            this.documento = documento;
            this.nombre = nombre;
            this.apellido = apellido;
            this.direccion = direccion;
        }

        public string Documento { get => documento; set => documento = value; }
        public string Nombre { get => nombre; set => nombre = value; }
        public string Apellido { get => apellido; set => apellido = value; }
        public string Direccion { get => direccion; set => direccion = value; }

        /// <summary>
        ///     Metodo para crear una entrada de empleado a la lista de registros.
        /// </summary>
        /// <param name="doc">  Aquí irá el documento de la persona </param>
        /// <param name="nom">  Nombre de la person </param>
        /// <param name="ape">  Apellido de la persona  </param>
        /// <param name="dir">  Direccion </param>
        /// <param name="list"> Lista, donde se agregara el registro    </param>
        public abstract void crearEntrada(string doc,string nom, string ape, string dir, ListView list);
        public abstract string calcularSueldo();
    }
}
