﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PracticaJuan_SalarioHerenciaPolimorfismo_03_30
{
    class Jefe : Empleado
    {
        private double sueldo; //Sueldo del jefe

        //Constructor del jefe con su sueldo fijo.
        public Jefe(string documento, string nombre, string apellido, string direccion, double sueldo = 2400000) : base(documento, nombre, apellido, direccion)
        {
            this.sueldo = sueldo;
        }

        //Devolvemos el sueldo del jefe, en este caso, sin calculos.
        public override string calcularSueldo()
        {
            return sueldo.ToString("N2");
        }

        //El epílogo de este método se encuentra la clase base, Empleado.
        public override void crearEntrada(string doc, string nom, string ape, string dir, ListView list)
        {
            //Comprobamos que todos los datos hallan sido ingresados.
            if (!string.IsNullOrEmpty(doc) && !string.IsNullOrEmpty(nom) && !string.IsNullOrEmpty(ape) && !string.IsNullOrEmpty(dir))
            {
                ListViewItem item = new ListViewItem("Jefe"); //Creamos un item para la lista.
                item.SubItems.Add(doc); //Le agregamos sus subelementos.
                item.SubItems.Add(ape);
                item.SubItems.Add(nom);
                item.SubItems.Add(dir);
                item.SubItems.Add(this.sueldo.ToString());
                list.Items.Add(item); //Agregamos el item a la lista
                this.sueldo = 0;
            }
            else
                throw new Exception("Ingrese todos los campos parce");
        }
    }
}
