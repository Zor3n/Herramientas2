﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PracticaJuan_SalarioHerenciaPolimorfismo_03_30
{
    class PorHoras : Empleado
    {
        private double salarioTotal; //Salario total del empleado
        private ushort salarioHora; //Pago por hora trabajada.
        private byte horas; //Horas trabajadas.

        //Constructor
        public PorHoras(string documento, string nombre, string apellido, string direccion, byte horas, ushort salarioHora) : base(documento, nombre, apellido, direccion)
        {
            this.horas = horas;
            this.salarioHora = salarioHora;
        }

        //Calculo del sueldo.
        public override string calcularSueldo()
        {
            this.salarioTotal = 0; //Reiniciamos el contador, para evitar alguna eventual falla.
            float incremento; //Incremento al valor de la hora cuando se exede de las 40.
            if (horas <= 0) //Si ingreso un numero menor o igual a 0 para las horas, tiramos una exepción.
            {
                throw new Exception("¿Por qué 0 o menos de cero horas, pana?");
            }
            else
            {
                if (horas > 40) //Cuando se ingresaron más de 40 horas, le aplicamos un aumento al valor de la hora.
                {
                    salarioTotal = (salarioHora * 40);
                    incremento = (horas - 40);
                    incremento = (incremento * salarioHora);
                    salarioTotal += (incremento * 1.20); //El incremento será de 20%
                }
                else
                {
                    salarioTotal = (salarioHora * horas);
                }
            }
            return salarioTotal.ToString("N2"); //Retornamos el salario total del empleado.
        }

        public override void crearEntrada(string doc, string nom, string ape, string dir, ListView list)
        {
            if (!string.IsNullOrEmpty(doc) && !string.IsNullOrEmpty(nom) && !string.IsNullOrEmpty(ape) && !string.IsNullOrEmpty(dir))
            {
                ListViewItem item = new ListViewItem("Por Horas");
                item.SubItems.Add(doc);
                item.SubItems.Add(ape);
                item.SubItems.Add(nom);
                item.SubItems.Add(dir);
                item.SubItems.Add(this.salarioTotal.ToString());
                list.Items.Add(item);
                this.salarioTotal = 0;
            }
            else
                throw new Exception("Ingrese todos los campos parce");
        }
    }
}
