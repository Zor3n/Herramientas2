﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PracticaJuan_SalarioHerenciaPolimorfismo_03_30
{
    public partial class frmPrincipal : Form
    {
        //Objeto a utilizar
        Empleado empleado;

        public frmPrincipal()
        {
            InitializeComponent();

            //Aquí iniciamos los datos del combo box y algunas etiquetas.
            cbEmpleados.Items.Add("Jefe");
            cbEmpleados.Items.Add("Comisionista");
            cbEmpleados.Items.Add("Por Horas");
            cbEmpleados.Items.Add("Fijo Mensual");
            lblSalarioComisionista.Text = "0";
            lblSalarioFijo.Text = "0";
            lblSaldoFijoJefe.Text = "0";
            lblSaldoHoras.Text = "0";
            lblNomina.Text = "0";
        }

        //Con este evento verificaremos el elemento del combobox seleccionado y haremos las habilitaciones y deshabilitaciones pertinentes.
        private void cbEmpleados_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbEmpleados.SelectedIndex >= 0 )
            {
                gbEmpleado.Enabled = true;
                if (cbEmpleados.SelectedItem.ToString() == "Comisionista")
                {
                    gbComisionista.Enabled = true;
                    gbHoras.Enabled = false;
                    label12.Enabled = false;
                    lblSaldoFijoJefe.Enabled = false;
                    label7.Enabled = false;
                    lblSalarioFijo.Enabled = false;
                }
                else if (cbEmpleados.SelectedItem.ToString() == "Por Horas")
                {
                    gbHoras.Enabled = true;
                    gbComisionista.Enabled = false;
                    label12.Enabled = false;
                    lblSaldoFijoJefe.Enabled = false;
                    label7.Enabled = false;
                    lblSalarioFijo.Enabled = false;
                }
                else if(cbEmpleados.SelectedItem.ToString() == "Jefe")
                {
                    label12.Enabled = true;
                    lblSaldoFijoJefe.Enabled = true;
                    gbHoras.Enabled = false;
                    gbComisionista.Enabled = false;
                    label7.Enabled = false;
                    lblSalarioFijo.Enabled = false;
                }
                else
                {
                    label7.Enabled = true;
                    lblSalarioFijo.Enabled = true;
                    gbHoras.Enabled = false;
                    gbComisionista.Enabled = false;
                    label12.Enabled = false;
                    lblSaldoFijoJefe.Enabled = false;
                }
            }
            else
            {
                gbEmpleado.Enabled = false;
            }
        }

        //Boton para agregar un nuevo objeto(Empleado)
        private void btnAgregar_Click(object sender, EventArgs e)
        {
            //Comparamos el elemento seleccionado del combobox y redireccionamos.
            switch (cbEmpleados.SelectedItem)
            {//Hay metodos para cada uno de los empleados.
                case "Jefe": jefe();
                    break;
                case "Comisionista": comisionistas();
                    break;
                case "Por Horas": porHoras();
                    break;
                case "Fijo Mensual": fijosMensuales();
                    break;
                default:
                    MessageBox.Show("Selecciones un tipo de empleado");
                    break;
            }

            //Con este condicional y el posterior bucle, sacaremos la nomina.
            if (lvDatos.Items.Count > 0) //Comprobamos que hay almenos un elemento en la lista
            {
                double nomina = 0; //Reiniciamos el contador de nomina.
                foreach  (ListViewItem x in lvDatos.Items) //Indicamos que vamos a recorrer un elemento en la lista.
                {
                    nomina += Convert.ToDouble(x.SubItems[5].Text); //Indicamos que queremos el subelemnto 5 del elemento en su propiedad "text".
                }
                lblNomina.Text = nomina.ToString("N2"); //Actualizamos la etiqueta.
            }
        }

        /// <summary>
        ///     Probamos agregar un nuevo Jefe
        /// </summary>
        private void jefe()
        {
            try //Probamos crear el objeto, le calculamos el sueldo, y creamos una entrada (Un registro en la lista de empleados)
            {
                empleado = new Jefe(txtDocumento.Text, txtNombre.Text, txtApellido.Text, txtDireccion.Text);
                lblSaldoFijoJefe.Text = empleado.calcularSueldo();
                empleado.crearEntrada(txtDocumento.Text, txtNombre.Text, txtApellido.Text, txtDireccion.Text, lvDatos);
            }
            catch (Exception M) //Si alguno tira una exepcion... Y repetimos el proceso con los demas tipos.
            {
                lblSaldoFijoJefe.Text = "0";
                MessageBox.Show(M.Message);
            }
        }

        /// <summary>
        ///     Probamos agregar un nuevo empleado por horas.
        /// </summary>
        private void porHoras()
        {
            try
            {
                empleado = new PorHoras(txtDocumento.Text, txtNombre.Text, txtApellido.Text, txtDireccion.Text,Convert.ToByte(txtHorasTrabajadas.Text),Convert.ToUInt16(txtSaldoHora.Text));
                lblSaldoHoras.Text = empleado.calcularSueldo();
                empleado.crearEntrada(txtDocumento.Text, txtNombre.Text, txtApellido.Text, txtDireccion.Text, lvDatos);
            }
            catch (Exception M)
            {
                lblSaldoHoras.Text = "0";
                MessageBox.Show(M.Message);
            }
        }

        /// <summary>
        ///     Probamos agregar un nuevo comisionista.
        /// </summary>
        private void comisionistas()
        {
            try
            {
                empleado = new Comisionistas(txtDocumento.Text, txtNombre.Text, txtApellido.Text, txtDireccion.Text, Convert.ToDouble(txtVentas.Text));
                lblSalarioComisionista.Text = empleado.calcularSueldo();
                empleado.crearEntrada(txtDocumento.Text, txtNombre.Text, txtApellido.Text, txtDireccion.Text, lvDatos);
            }
            catch (Exception M)
            {
                lblSalarioComisionista.Text = "0";
                MessageBox.Show(M.Message);
            }
        }

        /// <summary>
        ///     Probamos agregar un nuevo empleado con sueldo fijo
        /// </summary>
        private void fijosMensuales()
        {
            try
            {
                empleado = new FijosMensuales(txtDocumento.Text,txtNombre.Text, txtApellido.Text, txtDireccion.Text);
                lblSalarioFijo.Text = empleado.calcularSueldo();
                empleado.crearEntrada(txtDocumento.Text, txtNombre.Text, txtApellido.Text, txtDireccion.Text, lvDatos);                
            }
            catch (Exception M)
            {
                lblSalarioFijo.Text = "0";
                MessageBox.Show(M.Message);
            }
        }

        //Boton para salir.
        private void btnSalir_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
