﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace Practiva_DataGridView_2_0
{
    class Factura
    {
        private static int lista; //Contador de elementos en la lista

        /// <summary>
        ///     Constructor
        /// </summary>
        /// <param name="datos"> DTGV para iniciar el contador de elementos</param>
        public Factura(DataGridView datos)
        {
            lista = datos.Rows.Count + 1;  //Lo inicializamos con el numero de filas en el DTGV
        }

        /// <summary>
        ///     Mètodo para agregar los datos al DTGV
        /// </summary>
        /// <param name="nombre"> Contenido del text box Nombre </param>
        /// <param name="telefono"> Contenido del text box Telefono </param>
        /// <param name="genero"> Contenido del text box Genero </param>
        /// <param name="datos"> DTGV en donde se agregaran los datos </param>
        public void agregarDatos(string nombre, string telefono, string genero, DataGridView datos)
        {   //Comprobamos si los datos NO estan vacios
            if (!string.IsNullOrEmpty(nombre) && !string.IsNullOrEmpty(telefono) && !string.IsNullOrEmpty(genero))
            {   
                datos.Rows.Add(new object[] {lista,nombre,telefono,genero}); //Agregamos la nueva fila al DTGV
                lista += 1; //Aumnetamos el contador de elementos
            }
            else
                throw new Exception("Test error 1"); //Mensaje de error
        }

        /// <summary>
        ///     Mètodo para eliminar datos del DTGV
        /// </summary>
        /// <param name="n"> Esta serà el nùmero de fila seleccionada; la que se desea eliminar </param>
        /// <param name="datos"> DTGV de donde eliminaremos la fila elegida </param>
        public void eliminarDatos(int n,DataGridView datos)
        {   //Comprobamos si el numero de fila mandadò NO es NI el encabezado NI la ultima fila
            if (n != -1 && n != datos.Rows.Count -1)
            {
                datos.Rows.RemoveAt(n); //Eliminamos la fila
            }
        }
    }
}
