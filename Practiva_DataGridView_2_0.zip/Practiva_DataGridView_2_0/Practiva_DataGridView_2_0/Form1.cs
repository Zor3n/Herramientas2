﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Practiva_DataGridView_2_0
{
    public partial class frmInicio : Form
    {
        private static int cont; //Contador para el objeto timer, nos ayudara a realizar el cambio de imagen
        public frmInicio()
        {
            InitializeComponent();
        }
        private void frmInicio_FormClosing(object sender, FormClosingEventArgs e) //Con este evento
        {
            tmrConta.Stop(); //Garantizamos la finalizacion del evento tick y el cierre del timer
            tmrConta.Enabled = false; //Dos veces por que sì.
        }
        /// <summary>
        ///     Boton salir
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnSalir_Click(object sender, EventArgs e){this.Close(); tmrConta.Stop(); }

        /// <summary>
        ///     Boton para entrar al sistema
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnEntrar_Click(object sender, EventArgs e)
        {
            if (txtUsuario.Text.Contains("a") && txtContra.Text.Contains("a")) //Comprobamos el usuario y la contra
            {
                tmrConta.Start(); //De ser correcto iniciamos el timer
            }
            else
                MessageBox.Show("Test error 1");
        }

        /// <summary>
        ///     Evento tick del timer
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void tmrConta_Tick(object sender, EventArgs e)
        {
            cont++; //Cada vez que se produce un tick aumentamos el contador
            //lblIncremento.Text = cont.ToString(); //Lo mostramos en la etiqueta
            if (cont == 3) //Cueando el contador este en 3 hacemos el cambio de imagen
            {
                Image illuminati = Image.FromFile("pyramid.png"); //La imagen debe de estar en la carpeta Debug
                pictureBox1.Image = illuminati; //Agregamos la imagen al pictureBox
                pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage; //Cambiamos el tamaño
            }
            if (cont == 6) //Cuando llege a 6 pasamos al otro formulario
            {
                tmrConta.Stop(); //Paramos el timer
                frmFactura factura = new frmFactura();
                this.Hide();
                factura.ShowDialog();
            }
        }

        private void txtContra_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == Convert.ToChar(Keys.Enter)) //Verificar la tecla ingresada
            {
                if (txtUsuario.Text.Contains("a") && txtContra.Text.Contains("a")) //Comprobamos el usuario y la contra
                {
                    tmrConta.Start(); //De ser correcto iniciamos el timer
                }
                else
                    MessageBox.Show("Test error 1");
            }
        }
    }
}
