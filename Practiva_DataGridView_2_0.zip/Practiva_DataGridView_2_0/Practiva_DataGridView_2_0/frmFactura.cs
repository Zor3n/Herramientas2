﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Practiva_DataGridView_2_0
{
    public partial class frmFactura : Form
    {
        Factura factura; //La declaramos para que todos los metodos y eventos puedan acceder a ella
        private int n; //Igualmente con esta
        public frmFactura()
        {
            InitializeComponent();
            dtgvDatos.Rows.Add(new object[] { "1", "Marta", "11111", "Female" }); //Datos agregados para hacer pruebas
            dtgvDatos.Rows.Add(new object[] { "2", "Carla", "22222", "Female" }); //Tambien se podran agragar datos normalmente
            dtgvDatos.Rows.Add(new object[] { "3", "Carl", "33333", "Male" });
            dtgvDatos.Rows.Add(new object[] { "4", "Mateo", "44444", "Male" });
            factura = new Factura(dtgvDatos); //Al iniciar el formulario creamos el objeto
        }

        private void frmFactura_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit(); //Para garantizar el cierre del formulario
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            try//Probamos
            {
                factura.agregarDatos(txtNombre.Text,txtTelefono.Text,txtGenero.Text,dtgvDatos); //Agregamos
                txtNombre.Clear(); //Si se agrega limpiamos los campos
                txtTelefono.Clear();
                txtGenero.Clear();
            }
            catch (Exception mensaje)
            {
                MessageBox.Show(mensaje.Message); //Si no se agrega nos muestra un error
            }
        }

        private void dtgvDatos_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            n = e.RowIndex; //Extraemos el numero de fila
            int f = e.ColumnIndex; //Extraemos el numero de celda o columna

            if (n != -1 && n != dtgvDatos.Rows.Count - 1) //Se necesita cumplir con este requisito para mostrar, ya que la ultima fila siempre va ha estar vacia
                lblCelda.Text = dtgvDatos.Rows[n].Cells[f].Value.ToString(); //Mostramos el contenido en la etiqueta
            lblCelda.Visible = true; //Hacemos visible la etiqueta
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            factura.eliminarDatos(n,dtgvDatos); //Llamamos al metodo de la clase, mandandole el numero de fila seleccionada y el DTGV
        }
    }
}
