﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Practica_DataGridView_1_0
{
    class Factura
    {
        #region Variables
        private static int codigo; //Esta variable nos ayudara a poner el codigo al producto
        private int unidades; //Esta variable nos ayudara a verificar la cantidad de unidades ingresadas.
        private float precio; //Esta variable verificara el precio ingresado
        private float total; //Con esta variable sacaremos el total.
        private float todo; //Esta variable nos guardara el total de todas las facturas.
        #endregion

        #region Metodos
        /// <summary>
        ///     Constructor
        /// </summary>
        public Factura()
        {
            codigo = 100;
        }

        /// <summary>
        ///     Con este metodo haremos las facturas.
        /// </summary>
        /// <param name="nombre"> Este sera el nombre del producto</param>
        /// <param name="unidades"> Esta sera la cantidad de productos a llevar</param>
        /// <param name="precio"> Esta sera la variable que resibira el precio del producto</param>
        /// <param name="factura"> Esta sera donde almacenaremos los productos</param>
        /// <param name="todo"> Esta resibira donde iremos guardando el total de las facturas</param>
        public void hacerFactura(string nombre, string unidades,string precio,DataGridView factura, Label todo) 
        {
            //Comprobamos si todos los valores han sido ingresados.
            if (!string.IsNullOrEmpty(nombre) && !string.IsNullOrEmpty(unidades) && !string.IsNullOrEmpty(precio))
            {
                //Verificamos si lo ingresado han sido caracteres numericos.
                if (int.TryParse(unidades, out this.unidades) && float.TryParse(precio, out this.precio))
                {
                    total = (this.unidades * this.precio); //Hacemos el total del producto. 
                    this.todo += total; //Hacemos la suma de todos los totales.
                    factura.Rows.Add(new object[] {codigo,nombre,unidades,"$" + this.precio.ToString("N2"), "$" + total.ToString("N2") }); //Agregamos una nueva linea al DTGV
                    todo.Text = "$" + this.todo.ToString("N2"); //Actualizamos la etiqueta. 
                    codigo += 1; //Aumentamos el codigo.
                }else
                    throw new Exception("Ingrese los numericos correctamente");
            }
            else
                throw new Exception("Ingrese los valores");
        }

        /// <summary>
        ///     Con este metodo eliminaremos un elemento del DTGV
        /// </summary>
        /// <param name="factura"> DTGV a modificar</param>
        /// <param name="todo"> Al eliminarse un elemento de la factura, el valor total debe cambiar</param>
        public void borrarElemento(DataGridView factura,Label todo)
        {
            if (factura.SelectedRows.Count > 0 &&
            factura.SelectedRows[0].Index != factura.Rows.Count - 1)
            {
                factura.Rows.RemoveAt(factura.SelectedRows[0].Index);
            }
        }
        #endregion
    }
}
