﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Practica_DataGridView_1_0
{
    public partial class frmPrincipal : Form
    {
        Factura factura = new Factura(); //Creamos la factura.
        public frmPrincipal()
        {
            InitializeComponent();
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            try
            {
                factura.hacerFactura(txtNombre.Text,txtUnidades.Text,txtPrecio.Text, dtgvFactura,lblTotal);
                lblTotal.Visible = true;
                label4.Visible = true;
                txtNombre.Clear();
                txtUnidades.Clear();
                txtPrecio.Clear();
            }
            catch (Exception mensaje)
            {
                MessageBox.Show(mensaje.Message);
            }
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            //MessageBox.Show(dtgvFactura.SelectedRows.Count.ToString());
            //MessageBox.Show(dtgvFactura.Rows.Count.ToString());
            factura.borrarElemento(dtgvFactura,lblTotal);
            //if (dtgvFactura.SelectedRows.Count > 0 && dtgvFactura.SelectedRows[0].Index != dtgvFactura.Rows.Count - 1)
            //{
            //    dtgvFactura.Rows.RemoveAt(dtgvFactura.SelectedRows[0].Index);
            //}
        }
    }
}
